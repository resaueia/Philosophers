# Philosophers
The dining philosophers problem - 42 Project

This project implements the classic **"Dining Philosophers Problem"** using the C programming language. The program is designed to respect synchronization and threading constraints, using mutexes to prevent race conditions.
